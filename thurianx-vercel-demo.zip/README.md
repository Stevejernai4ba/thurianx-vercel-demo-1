# ThurianX Web App

Deployed with Vercel.

- Thai/English Language Toggle
- AI Durian Ripeness Detector
- Mobile Ready, Dark Mode
